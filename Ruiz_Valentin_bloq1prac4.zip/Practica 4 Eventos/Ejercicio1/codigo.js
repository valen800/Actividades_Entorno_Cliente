function onMouseOver(elemento) {
    elemento.style.fontSize = "16pt";
}

function onMouseOut(elemento) {
    elemento.style.fontSize = "12pt";
}